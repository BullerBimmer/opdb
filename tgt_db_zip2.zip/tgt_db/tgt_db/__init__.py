"""tgt_db — Targeting cyber database built on Neo4j."""

__version__ = "0.1.0"
