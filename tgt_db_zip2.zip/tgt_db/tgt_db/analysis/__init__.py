"""
Extensible analysis framework.

Each analyzer is a class that runs queries against the graph and returns
structured findings.  To add a new analyzer:

  1. Subclass ``BaseAnalyzer``.
  2. Implement ``run()``.
  3. Register it in ``REGISTRY``.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..db import TargetDB


class Finding:
    """A single analysis result."""

    def __init__(self, title: str, severity: str = "info",
                 detail: str = "", data: dict | None = None):
        self.title = title
        self.severity = severity   # info, low, medium, high, critical
        self.detail = detail
        self.data = data or {}

    def __repr__(self) -> str:
        return f"Finding({self.severity}: {self.title})"


class BaseAnalyzer(ABC):
    name: str = "base"
    description: str = ""

    @abstractmethod
    def run(self, db: "TargetDB", **kwargs: Any) -> list[Finding]:
        ...


from .network_analysis import (  # noqa: E402
    DualHomedHostAnalyzer,
    SharedSubnetAnalyzer,
    GatewayAnalyzer,
    StaleHostAnalyzer,
)
from .service_analysis import (  # noqa: E402
    CommonServiceAnalyzer,
    ExposedServiceAnalyzer,
    VersionAnalyzer,
)
from .credential_analysis import CredentialReuseAnalyzer  # noqa: E402
from .path_analysis import PathAnalyzer  # noqa: E402
from .temporal_analysis import (  # noqa: E402
    ChangeDetectionAnalyzer,
    DisappearedAnalyzer,
)
from .attack_path_analysis import (  # noqa: E402
    AttackScoreAnalyzer,
    AttackPathAnalyzer,
)
from .clustering_analysis import (  # noqa: E402
    ServiceClusterAnalyzer,
    OSClusterAnalyzer,
    OutlierAnalyzer,
)
from .segmentation_analysis import (  # noqa: E402
    SegmentationScoreAnalyzer,
    SubnetMapAnalyzer,
)

REGISTRY: dict[str, BaseAnalyzer] = {
    # Network topology
    "dual-homed": DualHomedHostAnalyzer(),
    "shared-subnet": SharedSubnetAnalyzer(),
    "gateways": GatewayAnalyzer(),
    "stale-hosts": StaleHostAnalyzer(),
    # Services
    "common-services": CommonServiceAnalyzer(),
    "exposed-services": ExposedServiceAnalyzer(),
    "versions": VersionAnalyzer(),
    # Credentials
    "cred-reuse": CredentialReuseAnalyzer(),
    # Paths & attack
    "paths": PathAnalyzer(),
    "attack-score": AttackScoreAnalyzer(),
    "attack-paths": AttackPathAnalyzer(),
    # Temporal
    "changes": ChangeDetectionAnalyzer(),
    "disappeared": DisappearedAnalyzer(),
    # Clustering
    "service-clusters": ServiceClusterAnalyzer(),
    "os-clusters": OSClusterAnalyzer(),
    "outliers": OutlierAnalyzer(),
    # Segmentation
    "segmentation": SegmentationScoreAnalyzer(),
    "subnet-map": SubnetMapAnalyzer(),
}


def get_analyzer(name: str) -> BaseAnalyzer:
    if name not in REGISTRY:
        raise KeyError(f"Unknown analyzer '{name}'. Available: {list(REGISTRY)}")
    return REGISTRY[name]


def list_analyzers() -> list[tuple[str, str]]:
    return [(k, v.description) for k, v in REGISTRY.items()]


def run_all(db: "TargetDB", **kwargs: Any) -> dict[str, list[Finding]]:
    """Run every registered analyzer and return findings grouped by name."""
    results: dict[str, list[Finding]] = {}
    for name, analyzer in REGISTRY.items():
        try:
            results[name] = analyzer.run(db, **kwargs)
        except Exception as e:
            results[name] = [Finding(
                title=f"Analyzer error: {e}",
                severity="info",
                detail=str(e),
            )]
    return results
